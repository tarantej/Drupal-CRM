# RedHen Notes

## Description

The RedHen Notes module allows you to add notes to contact and organization entities in your CRM. Since "note" is an entity bundle, RedHen notes are also fieldable. Using a combination of fields, Views, and Rules, you can quickly extend the Notes module for managing simple scheduling/follow-up workflows.

This module optionally integrates with the RedHen Engagement Score module. See that module's README.txt for more information.