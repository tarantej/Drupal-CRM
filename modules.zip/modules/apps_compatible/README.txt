Apps compatible provides methods to help multiple Apps or Features to play
nicely together.

See the apps_compatible.api.php file for hook-related information.

See the project page at http://drupal.org/project/apps.
